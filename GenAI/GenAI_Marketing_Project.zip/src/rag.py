
from sentence_transformers import SentenceTransformer
import faiss
import numpy as np

class RAGRetriever:
    def __init__(self, model_name='all-MiniLM-L6-v2'):
        try:
            self.embed_model = SentenceTransformer(model_name)
            self.index = None
            self.docs = []
        except Exception as e:
            print('RAG init error:', e)
            self.embed_model = None
            self.index = None
            self.docs = []

    def build_index(self, docs):
        embeddings = self.embed_model.encode(docs, convert_to_numpy=True)
        dim = embeddings.shape[1]
        index = faiss.IndexFlatL2(dim)
        index.add(embeddings)
        self.index = index
        self.docs = docs

    def retrieve(self, query, top_k=3):
        if not self.index:
            return []
        q_emb = self.embed_model.encode([query], convert_to_numpy=True)
        D, I = self.index.search(q_emb, top_k)
        results = [self.docs[i] for i in I[0] if i < len(self.docs)]
        return results

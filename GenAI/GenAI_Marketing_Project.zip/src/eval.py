
from typing import List
from rouge_score import rouge_scorer
import nltk
nltk.download('punkt')

def rouge_score(reference:str, candidate:str):
    scorer = rouge_scorer.RougeScorer(['rouge1','rouge2','rougeL'], use_stemmer=True)
    return scorer.score(reference, candidate)

def readability_score(text:str):
    from nltk.tokenize import sent_tokenize, word_tokenize
    sents = sent_tokenize(text)
    words = word_tokenize(text)
    if len(sents)==0:
        return 0
    return len(words)/len(sents)

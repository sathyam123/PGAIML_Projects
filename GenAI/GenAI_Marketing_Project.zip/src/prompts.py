
from typing import Dict, Any

class PromptLibrary:
    def __init__(self):
        pass

    def build_prompt(self, format:str, product:Dict[str,Any], audience:str=None, tone:str="professional", context:str="") -> str:
        base = f"Product: {product.get('name')}\nCategory: {product.get('category')}\nFeatures: {product.get('features')}\nDescription: {product.get('short_description')}\n"
        if audience:
            base += f"Target Audience: {audience}\n"
        if context:
            base += f"Context: {context}\n"
        instr = ""
        if format == "email":
            instr = "Write a marketing email (subject + 3 short paragraphs) in the requested tone that highlights benefits and includes a CTA."
        elif format == "ad":
            instr = "Write 3 short ad copies (<= 90 characters) suitable for social media paid ads focusing on the product's key benefit."
        elif format == "caption":
            instr = "Write 5 social media captions with hashtags, each <= 150 characters."
        elif format == "description":
            instr = "Write a product landing page description (100-200 words) with bullet list features."
        else:
            instr = f"Generate content of type: {format}"
        prompt = base + "\nInstruction: " + instr + "\nTone: " + tone + "\n"
        return prompt

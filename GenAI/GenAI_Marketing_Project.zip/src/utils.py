
import json, os

def load_sample_products():
    base = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
    sample_file = os.path.join(base, 'sample_data', 'sample_products.json')
    with open(sample_file, 'r') as f:
        return json.load(f)

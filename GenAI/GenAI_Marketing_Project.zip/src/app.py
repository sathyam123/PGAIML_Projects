
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import List, Optional
from .generator import CampaignGenerator
from .utils import load_sample_products

app = FastAPI(title="GenAI Marketing Campaign Generator")
generator = CampaignGenerator()

class GenerateRequest(BaseModel):
    product_id: Optional[str] = None
    product: Optional[dict] = None
    audience: Optional[str] = None
    tone: Optional[str] = "professional"
    formats: List[str] = ["email","ad","caption"]
    use_rag: Optional[bool] = False

@app.get("/")
def home():
    return {"status":"ok", "message":"GenAI Marketing Campaign Generator API"}

@app.post("/generate")
def generate(req: GenerateRequest):
    product = None
    if req.product:
        product = req.product
    elif req.product_id:
        products = load_sample_products()
        product = next((p for p in products if p["id"]==req.product_id), None)
    if not product:
        raise HTTPException(status_code=400, detail="Product not found.")
    outputs = generator.generate_campaign(product=product, audience=req.audience, tone=req.tone, formats=req.formats, use_rag=req.use_rag)
    return {"product_id": product.get("id","NA"), "outputs": outputs}

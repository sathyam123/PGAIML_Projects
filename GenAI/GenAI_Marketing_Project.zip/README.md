# Advanced GenAI for NLP — Marketing Campaign Generator

**Project purpose:** Production-ready codebase for generating multi-format marketing campaigns (emails, ad copy, product descriptions, social captions) using LLMs and RAG.  
This repo includes a FastAPI app, prompt library, RAG skeleton (embeddings + vector store), evaluation utilities, and deployment artifacts.

## Quick start
1. Create Python 3.10+ virtualenv.
2. pip install -r requirements.txt
3. uvicorn src.app:app --reload --host 0.0.0.0 --port 8000
4. Open http://localhost:8000/docs

## Structure
See /src for code: app.py, generator.py, prompts.py, rag.py, eval.py, utils.py

# Pneumonia Detection — Computer Vision Project (Industry-ready)

This repository is an industry-ready project structure for Pneumonia detection from chest X-ray images.
It is built from your uploaded notebook (SATHYAMOORTHY_Pnuemonia Detection_Notebook.html). See source: SATHYAMOORTHY_Pnuemonia Detection_Notebook.html. fileciteturn4file0

## Features included
- Data ingestion & preprocessing pipeline (image loading, resizing, augmentation, class balancing)
- Training scripts with Transfer Learning (EfficientNet/VGG options) and custom CNN fallback
- Advanced training: class weights, focal loss, mixup augmentation examples
- Model evaluation (confusion matrix, precision/recall/F1, ROC AUC) and error analysis
- Inference script and FastAPI server for model serving
- Dockerfile and requirements for containerized deployment
- Example unit tests for data loader and inference
- Notebook for exploratory analysis and sample visualizations (linked to original notebook)

## Quick start (development)
1. Create Python 3.8+ virtualenv
2. pip install -r requirements.txt
3. Place dataset in `data/` as `train/val/test` folders or provide CSV with image paths and labels.
4. Train:
   ```bash
   python src/train.py --config configs/train_config.yaml
   ```
5. Serve model:
   ```bash
   uvicorn src.app:app --reload --host 0.0.0.0 --port 8000
   ```
6. API docs: http://localhost:8000/docs

## Project structure
```
ComputerVision_Pneumonia_Project/
├─ README.md
├─ requirements.txt
├─ Dockerfile
├─ configs/
│  └─ train_config.yaml
├─ data/            # (not included) put dataset here
├─ src/
│  ├─ data.py
│  ├─ models.py
│  ├─ train.py
│  ├─ inference.py
│  ├─ app.py
│  ├─ utils.py
│  └─ eval.py
├─ notebooks/
│  └─ exploratory_analysis.ipynb  (link to your uploaded notebook)
└─ tests/
   └─ test_data_loader.py
```

## Notes
- This project was scaffolded based on the analysis and outputs visible in your uploaded notebook (model choices VGG16, custom CNN, dataset shapes ~30k images, preprocessing to 64x64) which showed underfitting issues and evaluation metrics. See notebook for details. fileciteturn4file0
- Replace placeholder LLM/weights calls and adjust hyperparameters based on your compute.
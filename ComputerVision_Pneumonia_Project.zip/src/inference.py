import numpy as np, cv2, torch
from src.models import get_model
from src.utils import load_model, to_device

def predict(image_path, model_path, img_size=224, device='cpu'):
    img = cv2.imread(image_path)
    img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    img = cv2.resize(img, (img_size, img_size)).astype('float32')/255.0
    img = np.transpose(img, (2,0,1))
    x = torch.tensor([img]).float()
    model = get_model(name='efficientnet_b0', pretrained=False, num_classes=2)
    model = load_model(model, model_path, device=device)
    with torch.no_grad():
        out = model(x.to(device))
        p = torch.softmax(out, dim=1)[:,1].cpu().numpy()[0]
    return p
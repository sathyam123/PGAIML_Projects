import os, random
from pathlib import Path
from typing import List, Tuple
import cv2
import numpy as np
from torch.utils.data import Dataset

class PneumoniaDataset(Dataset):
    def __init__(self, records: List[Tuple[str,int]], img_size:int=224, augment=None):
        self.records = records
        self.img_size = img_size
        self.augment = augment

    def __len__(self):
        return len(self.records)

    def __getitem__(self, idx):
        path, label = self.records[idx]
        img = cv2.imread(path, cv2.IMREAD_COLOR)
        img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        img = cv2.resize(img, (self.img_size, self.img_size))
        img = img.astype('float32') / 255.0
        # HWC -> CHW
        img = np.transpose(img, (2,0,1))
        return img, int(label)

def load_records_from_folder(base_path:str, classes:List[str]=['NORMAL','PNEUMONIA']):
    records = []
    for cls in classes:
        cls_path = os.path.join(base_path, cls)
        if not os.path.exists(cls_path):
            continue
        for fname in os.listdir(cls_path):
            if fname.lower().endswith(('.png','.jpg','.jpeg')):
                records.append((os.path.join(cls_path,fname), 0 if cls==classes[0] else 1))
    return records
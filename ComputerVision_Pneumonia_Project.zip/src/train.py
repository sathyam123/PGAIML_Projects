import os, yaml, argparse, time
import torch, torch.nn as nn, torch.optim as optim
from torch.utils.data import DataLoader
from sklearn.model_selection import train_test_split
from src.data import PneumoniaDataset, load_records_from_folder
from src.models import get_model
from src.utils import save_model, compute_class_weights, to_device, collate_fn
from src.eval import evaluate_model

def train(config):
    data_dir = config['paths']['data_dir']
    records = load_records_from_folder(os.path.join(data_dir,'train'))
    train_recs, val_recs = train_test_split(records, test_size=0.1, stratify=[r[1] for r in records])
    train_ds = PneumoniaDataset(train_recs, img_size=config['train']['img_size'])
    val_ds = PneumoniaDataset(val_recs, img_size=config['train']['img_size'])
    train_loader = DataLoader(train_ds, batch_size=config['train']['batch_size'], shuffle=True)
    val_loader = DataLoader(val_ds, batch_size=config['train']['batch_size'], shuffle=False)

    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    model = get_model(name=config['train']['model_name'], pretrained=config['train']['pretrained'])
    model.to(device)

    criterion = nn.CrossEntropyLoss(weight=compute_class_weights(train_recs))
    optimizer = optim.Adam(model.parameters(), lr=config['train']['lr'])

    best_val = 0.0
    for epoch in range(config['train']['epochs']):
        model.train()
        total_loss = 0.0
        for imgs, labels in train_loader:
            imgs = to_device(torch.tensor(imgs), device).float()
            labels = to_device(torch.tensor(labels), device).long()
            outputs = model(imgs)
            loss = criterion(outputs, labels)
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            total_loss += loss.item()
        val_metrics = evaluate_model(model, val_loader, device)
        print(f'Epoch {epoch+1}/{config["train"]["epochs"]} - train_loss: {total_loss:.4f} val_f1: {val_metrics["f1"]:.4f}')
        if val_metrics['f1'] > best_val:
            best_val = val_metrics['f1']
            save_model(model, os.path.join(config['paths']['output_dir'],'best_model.pth'))

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--config', default='configs/train_config.yaml')
    args = parser.parse_args()
    with open(args.config) as f:
        config = yaml.safe_load(f)
    os.makedirs(config['paths']['output_dir'], exist_ok=True)
    train(config)
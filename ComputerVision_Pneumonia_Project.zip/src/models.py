import torch
import torch.nn as nn
import torchvision.models as models

def get_model(name='efficientnet_b0', pretrained=True, num_classes=2):
    if name.startswith('efficientnet'):
        model = models.efficientnet_b0(pretrained=pretrained)
        in_features = model.classifier[1].in_features
        model.classifier[1] = nn.Linear(in_features, num_classes)
        return model
    elif name=='vgg16':
        model = models.vgg16(pretrained=pretrained)
        in_features = model.classifier[6].in_features
        model.classifier[6] = nn.Linear(in_features, num_classes)
        return model
    else:
        # simple CNN fallback
        class SimpleCNN(nn.Module):
            def __init__(self, num_classes=2):
                super().__init__()
                self.features = nn.Sequential(
                    nn.Conv2d(3,32,3,padding=1), nn.ReLU(), nn.MaxPool2d(2),
                    nn.Conv2d(32,64,3,padding=1), nn.ReLU(), nn.MaxPool2d(2),
                    nn.Conv2d(64,128,3,padding=1), nn.ReLU(), nn.AdaptiveAvgPool2d(1)
                )
                self.classifier = nn.Sequential(nn.Flatten(), nn.Linear(128, num_classes))
            def forward(self,x):
                x = self.features(x)
                x = self.classifier(x)
                return x
        return SimpleCNN(num_classes=num_classes)
from fastapi import FastAPI, File, UploadFile, HTTPException
from pydantic import BaseModel
import uuid, os
from src.inference import predict

app = FastAPI(title='Pneumonia Detection Inference API')

MODEL_PATH = './models/best_model.pth'

@app.get('/')
def home():
    return {'status':'ok','model': MODEL_PATH}

@app.post('/predict')
async def predict_api(file: UploadFile = File(...)):
    if not file.filename.lower().endswith(('.png','.jpg','.jpeg')):
        raise HTTPException(status_code=400, detail='Invalid file type.')
    tmp_file = f'/tmp/{uuid.uuid4().hex}_{file.filename}'
    contents = await file.read()
    with open(tmp_file, 'wb') as f:
        f.write(contents)
    prob = predict(tmp_file, MODEL_PATH, img_size=224, device='cpu')
    os.remove(tmp_file)
    return {'pneumonia_probability': float(prob)}
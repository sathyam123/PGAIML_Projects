import torch, numpy as np
from sklearn.metrics import precision_recall_fscore_support, roc_auc_score, confusion_matrix

def evaluate_model(model, loader, device='cpu'):
    model.eval()
    ys, preds, probs = [], [], []
    with torch.no_grad():
        for imgs, labels in loader:
            imgs = torch.tensor(imgs).to(device).float()
            labels = labels
            outputs = model(imgs)
            p = torch.softmax(outputs, dim=1)[:,1].cpu().numpy()
            y_pred = (p>0.5).astype(int)
            ys.extend(labels)
            preds.extend(y_pred.tolist())
            probs.extend(p.tolist())
    precision, recall, f1, _ = precision_recall_fscore_support(ys, preds, average='binary', zero_division=0)
    auc = roc_auc_score(ys, probs) if len(set(ys))>1 else 0.0
    cm = confusion_matrix(ys, preds)
    return {'precision':precision, 'recall':recall, 'f1':f1, 'auc':auc, 'confusion_matrix': cm.tolist()}
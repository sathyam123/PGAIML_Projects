import os, torch, numpy as np
from sklearn.utils.class_weight import compute_class_weight

def save_model(model, path):
    torch.save(model.state_dict(), path)

def load_model(model, path, device='cpu'):
    model.load_state_dict(torch.load(path, map_location=device))
    model.to(device)
    model.eval()
    return model

def compute_class_weights(records):
    labels = [r[1] for r in records]
    classes = list(set(labels))
    cw = compute_class_weight(class_weight='balanced', classes=classes, y=labels)
    # return tensor weights in correct order
    import torch
    order = [cw[classes.index(c)] for c in sorted(classes)]
    return torch.tensor(order, dtype=torch.float)

def to_device(x, device):
    return x.to(device)
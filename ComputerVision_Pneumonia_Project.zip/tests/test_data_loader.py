import os
from src.data import load_records_from_folder
def test_load_records():
    # create dummy folder structure and files
    base = 'tests_dummy'
    os.makedirs(os.path.join(base,'NORMAL'), exist_ok=True)
    os.makedirs(os.path.join(base,'PNEUMONIA'), exist_ok=True)
    open(os.path.join(base,'NORMAL','n1.jpg'),'a').close()
    open(os.path.join(base,'PNEUMONIA','p1.jpg'),'a').close()
    recs = load_records_from_folder(base)
    assert len(recs) >= 2
    # cleanup
    import shutil
    shutil.rmtree(base)